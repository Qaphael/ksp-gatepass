# KSP GatePass logo assets and wiring

Copy the folders in this pack into the repo root (they match the repo's paths). Preview: `preview/logo-sheet.png`.

## 1. Copy files

```
public/brand/**                      new
public/icons/icon-*.png              new
src/app/icon.svg                     new
src/app/favicon.ico                  replaces the old one
src/app/apple-icon.png               replaces the old one
src/app/manifest.ts                  replaces the old one
src/lib/brand/logo-mark.ts           new
src/components/brand/logo-mark.tsx   new
scripts/generate-pwa-icons.mjs       replaces the old one
docs/BRAND.md                        new
```

## 2. Remove the old placeholder assets

```
public/icons/ksp-gatepass-placeholder.svg
public/icons/ksp-gatepass-192.png
public/icons/ksp-gatepass-512.png
```
Then check nothing still points at them: `grep -rn "ksp-gatepass-192\|ksp-gatepass-512\|ksp-gatepass-placeholder" src docs scripts` (docs/OPERATIONS.md and docs/TASKS.md mention icons; update the filenames there). The Next starter SVGs in `public/` (next.svg, vercel.svg, globe.svg, window.svg, file.svg) are unused and can go too.

## 3. Use the mark in the UI

`src/app/(dashboard)/layout.tsx`, add the import:
```tsx
import { BrandLockup, LogoMark } from "@/components/brand/logo-mark";
```
Desktop sidebar, replace
```tsx
<Link href={landing} className="mb-6 px-2 font-semibold tracking-tight">KSP GatePass</Link>
```
with
```tsx
<Link href={landing} aria-label="KSP GatePass home" className="mb-6 block px-2"><BrandLockup /></Link>
```
Mobile header, replace
```tsx
<Link href={landing} className="shrink-0 font-semibold tracking-tight">KSP</Link>
```
with
```tsx
<Link href={landing} aria-label="KSP GatePass home" className="flex size-11 shrink-0 items-center justify-center"><LogoMark className="size-8 text-primary" /></Link>
```
(the 44 px link keeps the tap target to spec).

`src/app/(auth)/layout.tsx`, add the same import and replace the sign-in heading link with
```tsx
<Link href="/" className="inline-flex flex-col items-center gap-3">
  <LogoMark className="size-16 text-primary" />
  <span className="text-xl font-semibold tracking-tight">KSP GatePass</span>
</Link>
```
Colour comes from `currentColor`: use `text-primary` (brand-700) on light backgrounds and `text-white` or `text-ivory` on dark ones. Under 40 px add `variant="small"`.

## 4. Use the mark in PDFs

Receipts, issue slips and reports can draw the mark as vector with the same path data:
```tsx
import { Svg, Path } from "@react-pdf/renderer";
import { LOGO_MARK } from "@/lib/brand/logo-mark";

<Svg viewBox={LOGO_MARK.viewBox} style={{ width: 24, height: 24 }}>
  {LOGO_MARK.default.map((d) => <Path key={d} d={d} fill="#0f3d2e" />)}
</Svg>
```
The ticket itself uses your own artwork, so the mark is not drawn on it. The legacy ticket fallback still shows the text "KSP" in its band, and can use this component too.

## 5. Check it

1. `pnpm typecheck && pnpm lint && pnpm build`.
2. Chrome DevTools, Application, Manifest: all five icons load, and "any" and "maskable" are listed separately.
3. Open the site on your phone, check the browser tab icon, then **uninstall the old home-screen app and install it again**. Android caches the old icon until reinstall. Browsers also cache favicons hard, so hard-refresh or check in a private window.
4. Look at the sign-in screen and the dashboard header at 360 px wide.
