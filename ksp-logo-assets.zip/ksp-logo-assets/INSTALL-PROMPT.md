# Install prompt

Put `ksp-logo-assets.zip` in the repo root. Paste this into opencode or Codex (Build / Agent mode):

```
I put ksp-logo-assets.zip in the repo root. Install the logo assets and wire them in, step by step.

1. Extract the zip to a temporary folder outside the repo. Read its README.md and docs/BRAND.md. Confirm it contains public/brand, public/icons, src/app (icon.svg, favicon.ico, apple-icon.png, manifest.ts), src/lib/brand/logo-mark.ts, src/components/brand/logo-mark.tsx and scripts/generate-pwa-icons.mjs. If anything is missing, tell me and stop.

2. Copy the files into the repo at the same paths. Replace src/app/favicon.ico, src/app/apple-icon.png, src/app/manifest.ts and scripts/generate-pwa-icons.mjs, and show me the manifest.ts diff. Do not overwrite anything else without asking.

3. Ask me before deleting the old placeholders (public/icons/ksp-gatepass-placeholder.svg, ksp-gatepass-192.png, ksp-gatepass-512.png). After I confirm, delete them and search src, docs and scripts for any remaining references. Update docs/OPERATIONS.md and docs/TASKS.md filenames if they mention the old icons.

4. Make the three edits from section 3 of the README: the sidebar lockup and mobile header mark in src/app/(dashboard)/layout.tsx, and the sign-in heading in src/app/(auth)/layout.tsx. Keep every other line of those files unchanged. Do not change logic, permissions or routes.

5. Add the content of docs/BRAND.md to docs/ and add one line under the Brand section of docs/DESIGN.md pointing to it.

6. Run: node scripts/generate-pwa-icons.mjs, then pnpm typecheck, pnpm lint and pnpm build. Report the real results. If the script changed any PNG, tell me which.

7. Show me what the sign-in page and dashboard header look like at 360 px wide (Playwright screenshot if it is already set up, otherwise tell me how to check).

8. Ask me before deleting the zip and the temporary folder. Show git status and a short summary. Do not commit and do not push.
```
